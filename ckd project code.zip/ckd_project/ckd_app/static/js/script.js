// static/js/script.js
document.addEventListener("DOMContentLoaded", function () {
  alert("JavaScript Loaded Successfully!");
});
